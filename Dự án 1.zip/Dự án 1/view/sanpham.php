<div id="sanpham">
  <div class="container">
    <div class="row">
      <div class="col-sm-push-3 product-grid">
        <div class="pro-coloumn">
          <article class="col-main">
            <div class="category-products">
              <ul class="products-grid">
                <li class="item col-lg-4 col-md-3 col-sm-4 col-xs-6">
                  <div class="item-inner">
                    <div class="item-img">
                      <div class="item-img-info"><a href="index.php?act=chitietsp" title="Retis lapen casen"
                          class="product-image"><img src="../view/images/custom-img1.jpg" alt="Retis lapen casen"></a>
                        <div class="new-label new-top-left">Used</div>
                        <div class="sale-label sale-top-left">-15%</div>
                        <div class="item-box-hover">
                          <div class="box-inner">
                            <div class="add_cart">
                              <a href="index.php?act=chitietsp"><button class="button btn-cart"
                                  type="button"></button></a>
                            </div>
                            <div class="product-detail-bnt"><a class="button detail-bnt"><span>Quick View</span></a>
                            </div>
                            <div class="actions"><span class="add-to-links"><a href="#" class="link-wishlist"
                                  title="Add to Wishlist"><span>Add to Wishlist</span></a> </span> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item-info">
                      <div class="info-inner">
                        <div class="item-title"><a href="index.php?act=chitietsp" title="Retis lapen casen">Gorgeous
                            Mercedes-Benz E-Class All-Terrain Luxury</a> </div>
                        <div class="item-content">
                          <div class="item-price">
                            <div class="price-box"><span class="regular-price"><span class="price">$49000.00</span>
                              </span> </div>
                          </div>
                          <div class="other-info">
                            <div class="col-km"><i class="fa fa-car"></i> Petrol</div>
                            <div class="col-engine"><i class="fa fa-calendar"></i> 2021 Model</div>
                            <div class="col-date"><i class="fa fa-user" aria-hidden="true"></i> 4 seats </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
                <li class="item col-lg-4 col-md-3 col-sm-4 col-xs-6">
                  <div class="item-inner">
                    <div class="item-img">
                      <div class="item-img-info"><a href="index.php?act=chitietsp" title="Retis lapen casen"
                          class="product-image"><img src="../view/images/custom-img1.jpg" alt="Retis lapen casen"></a>
                        <div class="item-box-hover">
                          <div class="box-inner">
                            <div class="add_cart">
                              <button class="button btn-cart" type="button"></button>
                            </div>
                            <div class="product-detail-bnt"><a class="button detail-bnt"><span>Quick View</span></a>
                            </div>
                            <div class="actions"><span class="add-to-links"><a href="#" class="link-wishlist"
                                  title="Add to Wishlist"><span>Add to Wishlist</span></a> </span> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item-info">
                      <div class="info-inner">
                        <div class="item-title"><a href="index.php?act=chitietsp" title="Retis lapen casen">Gorgeous
                            Mercedes-Benz E-Class All-Terrain Luxury</a> </div>
                        <div class="item-content">
                          <div class="item-price">
                            <div class="price-box"><span class="regular-price"><span class="price">$49000.00</span>
                              </span> </div>
                          </div>
                          <div class="other-info">
                            <div class="col-km"><i class="fa fa-car"></i> Petrol</div>
                            <div class="col-engine"><i class="fa fa-calendar"></i> 2021 Model</div>
                            <div class="col-date"><i class="fa fa-user" aria-hidden="true"></i> 4 seats </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
                <li class="item col-lg-4 col-md-3 col-sm-4 col-xs-6">
                  <div class="item-inner">
                    <div class="item-img">
                      <div class="item-img-info"><a href="index.php?act=chitietsp" title="Retis lapen casen"
                          class="product-image"><img src="../view/images/custom-img1.jpg" alt="Retis lapen casen"></a>
                        <div class="item-box-hover">
                          <div class="box-inner">
                            <div class="add_cart">
                              <button class="button btn-cart" type="button"></button>
                            </div>
                            <div class="product-detail-bnt"><a class="button detail-bnt"><span>Quick View</span></a>
                            </div>
                            <div class="actions"><span class="add-to-links"><a href="#" class="link-wishlist"
                                  title="Add to Wishlist"><span>Add to Wishlist</span></a> </span> </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item-info">
                      <div class="info-inner">
                        <div class="item-title"><a href="index.php?act=chitietsp" title="Retis lapen casen">Gorgeous
                            Mercedes-Benz E-Class All-Terrain Luxury</a> </div>
                        <div class="item-content">
                          <div class="item-price">
                            <div class="price-box"><span class="regular-price"><span class="price">$49000.00</span>
                              </span> </div>
                          </div>
                          <div class="other-info">
                            <div class="col-km"><i class="fa fa-car"></i> Petrol</div>
                            <div class="col-engine"><i class="fa fa-calendar"></i> 2021 Model</div>
                            <div class="col-date"><i class="fa fa-user" aria-hidden="true"></i> 4 seats </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </article>
        </div>
      </div>
    </div>
  </div>
  </section>
</div>