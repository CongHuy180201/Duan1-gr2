
<footer>
    <div class="footer-inner">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 col-xs-12 col-lg-4">
                    <div class="co-info">
                        <h4>Poly Car</h4>
                        <address>
                        <div><span>Cao đẳng FPTpoly <br>
                        VN 2022 Tương lai</span></div>
                        <div> <span> 0909090909</span></div>
                        <div> <span><a href="#">PS****@pft.edu.vn</a></span></div>
                        </address>
                    </div>
                    </div>
                    <div class="col-sm-8 col-xs-12 col-lg-8">
                    <div class="footer-column">
                        <h4>Chính sách</h4>
                        <ul class="links">
                        <li class="first"><a title="How to buy" href="http://themesground.com/blog/">Blog</a></li>
                        <li><a title="FAQs" href="#">Giới thiệu về PolyCar</a></li>
                        <li><a title="Payment" href="#">Chính sách</a></li>
                        <li><a title="Shipment" href="#">Quy chế hoặt động</a></li>
                        <li><a title="Where is my order?" href="#">Bảo mật</a></li>
                        </ul>
                    </div>
                    <div class="footer-column">
                        <h4>Tìm hiểu thêm</h4>
                        <ul class="links">
                        <li class="first"><a title="Your Account" href="#">Hướng đẫn đặt xe</a></li>
                        <li><a title="Information" href="#">Hướng đẫn thanh toán</a></li>
                        <li><a title="Addresses" href="#">Hỏi đáp</a></li>
                        </ul>
                    </div>
                    <div class="footer-column">
                    <h4>Đối tác</h4>
                    <ul class="links">
                    <li class="first"><a title="Site Map" href="#">Đăng ký cho thuê xe</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-4">
                        <div class="social">
                            <ul>
                            <li class="fb"><a href="#"></a></li>
                            <li class="tw"><a href="#"></a></li>
                            <li class="googleplus"><a href="#"></a></li>
                            <li class="rss"><a href="#"></a></li>
                            <li class="pintrest"><a href="#"></a></li>
                            <li class="linkedin"><a href="#"></a></li>
                            <li class="youtube"><a href="#"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</footer>
</body>
</html>